/**************************************************************************//**
 * @file        A8107M0_LIB_IAP.h
 * @version     V1.00.00
 * $Revision:   0 $
 * $Date:       2018-01-12  $
 * @brief       A8107M0 FLASH IAP library function Header File
 *
 * @note
 *              V1.00.00 - Creat
 *
 * Copyright (C) 2018 AMICCOM Electronics Corp. All rights reserved.
 ******************************************************************************/

#ifndef __A8107M0_LIB_IAP_H__
#define __A8107M0_LIB_IAP_H__

#define A8107M0_IAP_PASS                    0
#define A8107M0_IAP_FAIL                    (~A8107M0_IAP_PASS)

#define A8107M0_FLASH_PAGE_SIZE             (128)
#define A8107M0_FLASH_SECTOR_SIZE           (4*1024)
#define A8107M0_FLASH_CHIP_SIZE             (128*1024)
#define A8107M0_FLASH_CHIP_NUMBER           (2)
#define A8107M0_ROM_SIZE                    (A8107M0_FLASH_CHIP_SIZE * A8107M0_FLASH_CHIP_NUMBER)

#define A8107M0_FLASH_PAGE_ADDRESS_MASK     0xFFFFFF80
#define A8107M0_FLASH_SECTOR_ADDRESS_MASK   0xFFFFF000
#define A8107M0_FLASH_BLANK_VALUE           0xFFFFFFFF


/**
 * @name    uint32_t IAPLIB_FlashProtect(void)
 *
 * @brief   Enable flash read protect to mask flash in debug mode.
 *
 * @param   none
 *
 * @return  A8107M0_IAP_PASS: PASS
 *          Others: FAIL
 */
extern uint32_t IAPLIB_FlashProtect(void);

/**
 * @name    uint32_t IAPLIB_FlashSectorEraseAndCheck(uint32_t address)
 * 
 * @brief   Erase 1 sector flash and check blank.
 *          This function will retry 9 times when check blank fail.
 *
 * @param   address: The address of sector that to erase. The address of sector is align by 4096 bytes.
 *                   This function will keep [bit6 : bit0] of address to 0 when sector erase. 
 *
 * @return  A8107M0_IAP_PASS: PASS
 *          Others: FAIL
 */
extern uint32_t IAPLIB_FlashSectorEraseAndCheck(uint32_t address);

/**
 * @name    uint32_t IAPLIB_FlashPageWriteAndCheck(uint32_t address, uint32_t *buf)
 * 
 * @brief   Write 1 page (32 words, 128bytes) data to flash and check it.
 *          This function will retry 9 times when check fail.
 *
 * @param   address: The address of page that to write.
 *                   address needs align by 128bytes.
 *
 * @return  A8107M0_IAP_PASS: PASS
 *          Others: FAIL
 */
extern uint32_t IAPLIB_FlashPageWriteAndCheck(uint32_t address, uint32_t *buf);

#endif
